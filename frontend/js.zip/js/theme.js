const toggle = document.getElementById("themeToggle");

const savedTheme = localStorage.getItem("theme") || "dark";

document.documentElement.setAttribute("data-theme", savedTheme);

updateIcon(savedTheme);

if (toggle) {
    toggle.addEventListener("click", () => {
        const currentTheme =
            document.documentElement.getAttribute("data-theme");

        const nextTheme =
            currentTheme === "dark"
                ? "light"
                : "dark";

        document.documentElement.setAttribute("data-theme", nextTheme);

        localStorage.setItem("theme", nextTheme);

        updateIcon(nextTheme);
    });
}

function updateIcon(theme) {
    if (!toggle) return;

    toggle.textContent = theme === "dark" ? "☀️" : "🌙";

    toggle.setAttribute(
        "aria-label",
        theme === "dark"
            ? "Switch to light mode"
            : "Switch to dark mode"
    );
}